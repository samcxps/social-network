README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1.Samson Cain, Lecture 001, xTeam 64, srcain@wisc.edu
2.Alex Denisov, Lecture 002, xTeam 102, denisov@wisc.edu
3.Xuanting Chen, Lecture 002, xTeam 122, xchen747@wisc.edu
4.Matvey Tkachev, Lecture 002, xTeam 112, tkachev@wisc.edu
5.Yonghee Han, Lecture 002, xTeam 122, yhan259@wisc.edu
 

Which team members were on same xteam together?
Xuanting Chen & Yonghee Han

Other notes or comments to the grader:

[place any comments or notes that will help the grader here]
