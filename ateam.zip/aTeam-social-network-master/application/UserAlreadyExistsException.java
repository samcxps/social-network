package application;

/**
 * 
 * @author samsoncain
 */
@SuppressWarnings("serial")
public class UserAlreadyExistsException extends Exception {

  /**
   * Default no-arg constructor 
   */
  public UserAlreadyExistsException() {}
    
}